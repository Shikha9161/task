package com.example.task1;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;

import android.os.Bundle;

import com.example.task1.databinding.ActivityMainBinding;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {
    ActivityMainBinding binding;
    List<Model> list = new ArrayList<>();
    MyListAdapter adapter;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding=ActivityMainBinding.inflate(getLayoutInflater());
        initvew();
        setContentView(binding.getRoot());
    }
    private void initvew() {
        list.add(new Model("What’s your favorite Product?", "Let’s discuss about basketball", "Let’s discuss about basketball","Let’s discuss about basketball"));
        list.add(new Model("Let’s discuss about basketball", "Let’s discuss about basketball", "Let’s discuss about basketball","Let’s discuss about basketball"));
        list.add(new Model("What’s your favorite Product?", "Let’s discuss about basketball", "Let’s discuss about basketball","Let’s discuss about basketball"));
        list.add(new Model("Let’s discuss about basketball", "Let’s discuss about basketball", "Let’s discuss about basketball","Let’s discuss about basketball"));
        list.add(new Model("What’s your favorite Product?", "Let’s discuss about basketball", "Let’s discuss about basketball","Let’s discuss about basketball"));
        list.add(new Model("Let’s discuss about basketball", "Let’s discuss about basketball", "Let’s discuss about basketball","Let’s discuss about basketball"));
        list.add(new Model("Let’s discuss about basketball", "Let’s discuss about basketball", "Let’s discuss about basketball","Let’s discuss about basketball"));
        adapter = new MyListAdapter(list, MainActivity.this);
        binding.rec.setAdapter(adapter);
        binding.rec.setLayoutManager(new LinearLayoutManager(MainActivity.this));
    }
}