package com.example.task1;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.recyclerview.widget.RecyclerView;

import java.util.Collections;
import java.util.List;

public class MyListAdapter extends RecyclerView.Adapter<MyListAdapter.ViewHolder>{
    List<Model> list = Collections.emptyList();
    Context context;
    public MyListAdapter(List<Model> list, Context context) {
        this.list = list;
        this.context = context;
    }  
    @Override  
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        LayoutInflater layoutInflater = LayoutInflater.from(parent.getContext());
        View listItem= layoutInflater.inflate(R.layout.view_layout, parent, false);
        ViewHolder viewHolder = new ViewHolder(listItem);  
        return viewHolder;  
    }  
  
    @Override  
    public void onBindViewHolder(ViewHolder holder, int position) {  
        final Model myListData = list.get(position);
        holder.header1.setText(list.get(position).getHeader1());
        holder.header2.setText(list.get(position).getHeader2());
        holder.header1_txt.setText(list.get(position).getHeader1_txt());
        holder.header2_txt.setText(list.get(position).getHeader2_txt());

    }  
  
  
    @Override  
    public int getItemCount() {  
        return list.size();
    }  
  
    public static class ViewHolder extends RecyclerView.ViewHolder {
        public TextView header1,header2,header1_txt,header2_txt;
        public ViewHolder(View itemView) {  
            super(itemView);
            this.header1 = (TextView) itemView.findViewById(R.id.header1);
            this.header2 = (TextView) itemView.findViewById(R.id.header2);
            this.header1_txt = (TextView) itemView.findViewById(R.id.header1_txt);
            this.header2_txt = (TextView) itemView.findViewById(R.id.header2_txt);
        }
    }  
}  