package com.example.task1;

public class Model {
    String header1;
    String header2;
    String header1_txt;
    String header2_txt;

    public String getHeader1() {
        return header1;
    }

    public void setHeader1(String header1) {
        this.header1 = header1;
    }

    public String getHeader2() {
        return header2;
    }

    public void setHeader2(String header2) {
        this.header2 = header2;
    }

    public String getHeader1_txt() {
        return header1_txt;
    }

    public void setHeader1_txt(String header1_txt) {
        this.header1_txt = header1_txt;
    }

    public String getHeader2_txt() {
        return header2_txt;
    }

    public void setHeader2_txt(String header2_txt) {
        this.header2_txt = header2_txt;
    }

    public Model(String header1, String header2, String header1_txt, String header2_txt) {
        this.header1 = header1;
        this.header2 = header2;
        this.header1_txt = header1_txt;
        this.header2_txt = header2_txt;
    }

    public Model() {
    }
}
